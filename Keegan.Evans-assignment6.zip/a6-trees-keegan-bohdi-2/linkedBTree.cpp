// Keegan Evans & Bohdi Norvell
// CS 302 HW 6 - Trees
// November 24, 2024

template <class ItemType>
LinkedBTree<ItemType>::LinkedBTree(){
    rootPtr = nullptr;
} 

template <class ItemType>
bool LinkedBTree<ItemType>::isEmpty() const{
    return rootPtr == nullptr;
}

template <class ItemType>
int LinkedBTree<ItemType>::getHeight() const{
    return getHeightHelper(rootPtr);

}

template <class ItemType>
int LinkedBTree<ItemType>::getNumberOfNodes() const{
    return getNumberOfNodesHelper(rootPtr);
}

template <class ItemType>
ItemType LinkedBTree<ItemType>::getRootData() const{
    return rootPtr->getItem();
}

template <class ItemType>
bool LinkedBTree<ItemType>::add(const ItemType& newData){
    LinkedTreeNode<ItemType>* newNodePtr = new LinkedTreeNode<ItemType>(newData);
    rootPtr = balancedAdd(rootPtr, newNodePtr);
    return true;
}

template <class ItemType>
bool LinkedBTree<ItemType>::remove(const ItemType& data){
    bool successful = false;
    rootPtr = removeValue(rootPtr, data, successful);
    return successful;
}

template <class ItemType>
void LinkedBTree<ItemType>::clear(){
    destroyTree(rootPtr);
    rootPtr = nullptr;
}

template <class ItemType>
ItemType LinkedBTree<ItemType>::getEntry(const ItemType & anEntry) const{
    bool isSuccessful = false;
    LinkedTreeNode<ItemType>* node = findNode(rootPtr, anEntry, isSuccessful);
    if (!isSuccessful) {
        throw "Entry not found in tree.";
    }
    return node->getItem();
}

template <class ItemType>
bool LinkedBTree<ItemType>::contains(const ItemType& anEntry) const{
    bool isSuccessful = false;
    findNode(rootPtr, anEntry, isSuccessful);
    return isSuccessful;
}

template <class ItemType>
LinkedBTree<ItemType>::~LinkedBTree(){
    clear();
}

template <class ItemType>
int LinkedBTree<ItemType>::getHeightHelper(LinkedTreeNode<ItemType>* subTreePtr) const{
    if (subTreePtr == nullptr){
        return 0; 
    }
    else{
        int leftHeight = getHeightHelper(subTreePtr->getLeftChildPtr());
        int rightHeight = getHeightHelper(subTreePtr->getRightChildPtr());

        if (leftHeight > rightHeight) {
            return leftHeight + 1;
        } 
        else{
            return rightHeight + 1;
        }
    }
}

template <class ItemType>
int LinkedBTree<ItemType>::getNumberOfNodesHelper(LinkedTreeNode<ItemType>* subTreePtr) const{
    if (subTreePtr == nullptr) {
        return 0; 
    } else{
        int leftCount = getNumberOfNodesHelper(subTreePtr->getLeftChildPtr());
        int rightCount = getNumberOfNodesHelper(subTreePtr->getRightChildPtr());
        return (rightCount + leftCount + 1);
    }
}

template <class ItemType>
LinkedTreeNode<ItemType>* LinkedBTree<ItemType>::balancedAdd(LinkedTreeNode<ItemType>* subTreePtr, LinkedTreeNode<ItemType>* newNodePtr){

    if(subTreePtr == nullptr){
        return newNodePtr;
    }
    else{
        LinkedTreeNode<ItemType>* leftPtr = subTreePtr->getLeftChildPtr();
        LinkedTreeNode<ItemType>* rightPtr = subTreePtr->getRightChildPtr();

        if(getHeightHelper(leftPtr) > getHeightHelper(rightPtr)){
            rightPtr = balancedAdd(rightPtr, newNodePtr);
            subTreePtr->setRightChildPtr(rightPtr);
        }
        else{
            leftPtr = balancedAdd(leftPtr, newNodePtr);
            subTreePtr->setLeftChildPtr(leftPtr);
        }
        return subTreePtr;
    }
}

template <class ItemType>
LinkedTreeNode<ItemType>* LinkedBTree<ItemType>::removeValue(LinkedTreeNode<ItemType>* subTreePtr, const ItemType target, bool& isSuccessful){
    if(subTreePtr == nullptr){
        isSuccessful = false;
        return nullptr;
    }
    else if(subTreePtr->getItem() == target){
        isSuccessful = true;
        if(subTreePtr->isLeaf()){
            delete subTreePtr;
            subTreePtr = nullptr;
            return subTreePtr;
        }
        else{
            return moveValuesUpTree(subTreePtr);
        }
    }
    else{
        LinkedTreeNode<ItemType>* tempPtr = removeValue(subTreePtr->getRightChildPtr(), target, isSuccessful);
        if(isSuccessful){
            subTreePtr->setRightChildPtr(tempPtr);
        }
        else{
            subTreePtr = removeValue(subTreePtr->getLeftChildPtr(), target, isSuccessful);
            if(isSuccessful){
                subTreePtr->setLeftChildPtr(tempPtr);
            }
        }
        return subTreePtr;
    }
}

template <class ItemType>
LinkedTreeNode<ItemType>* LinkedBTree<ItemType>::moveValuesUpTree(LinkedTreeNode<ItemType>* subTreePtr){
      LinkedTreeNode<ItemType>* nodeToConnectPtr;

    if(subTreePtr->getLeftChildPtr() == nullptr){
        nodeToConnectPtr = subTreePtr->getRightChildPtr();
        delete subTreePtr;
        subTreePtr = nullptr;
        return nodeToConnectPtr;
    }
    else if(subTreePtr->getRightChildPtr() == nullptr){
        nodeToConnectPtr = subTreePtr->getLeftChildPtr();
        delete subTreePtr;
        subTreePtr = nullptr;
        return nodeToConnectPtr;
    }
    else{
        LinkedTreeNode<ItemType>* largestNodePtr = subTreePtr->getLeftChildPtr();
        LinkedTreeNode<ItemType>* parentPtr = subTreePtr;
        
        while(largestNodePtr->getRightChildPtr() != nullptr){
            parentPtr = largestNodePtr;
            largestNodePtr = largestNodePtr->getRightChildPtr();
        }

        subTreePtr->setItem(largestNodePtr->getItem());

        if (parentPtr == subTreePtr){
            subTreePtr->setLeftChildPtr(largestNodePtr->getLeftChildPtr());
        }
        else{
            parentPtr->setRightChildPtr(largestNodePtr->getLeftChildPtr());
        }

        delete largestNodePtr;
        largestNodePtr = nullptr;

        return subTreePtr;
    }
}

template <class ItemType>
LinkedTreeNode<ItemType>* LinkedBTree<ItemType>::findNode(LinkedTreeNode<ItemType>* subTreePtr, const ItemType& target, bool& isSuccessful) const{
    if (subTreePtr == nullptr) {
        isSuccessful = false;
        return nullptr; 
    } 
    else if (subTreePtr->getItem() == target) {
        isSuccessful = true;
        return subTreePtr; 
    } 
    else{
        LinkedTreeNode<ItemType>* leftResult = findNode(subTreePtr->getLeftChildPtr(), target, isSuccessful);
        if (isSuccessful){
            return leftResult;
        } 
        else{
            return findNode(subTreePtr->getRightChildPtr(), target, isSuccessful);
        }
    }
}

template <class ItemType>
void LinkedBTree<ItemType>::destroyTree(LinkedTreeNode<ItemType>* subTreePtr){
    if(subTreePtr != nullptr){
        destroyTree(subTreePtr->getLeftChildPtr());
        destroyTree(subTreePtr->getRightChildPtr());
        delete subTreePtr;
    }
}
