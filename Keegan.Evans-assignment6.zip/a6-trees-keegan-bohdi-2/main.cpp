// Keegan Evans & Bohdi Norvell
// CS 302 HW 6 - Trees
// November 24, 2024

#include <iostream>
#include <fstream>
#include "linkedBSearchTree.h"

using namespace std;

void print(int&);

int main() {
    LinkedBSearchTree<int> binarySearchTree;
    freopen("binarySearchTreeTraversal.txt", "w", stdout);
    cout << "Original Order of Random Numbers: ";
    srand(time(0));
    for (int i = 0; i < 100; ++i){
    int value;
        do {
            value = rand() % 200 + 1;
        }while(binarySearchTree.contains(value));
        binarySearchTree.add(value); 
        cout << value << " ";
    }
    cout << endl << endl;


    cout << "Height of the tree: " << binarySearchTree.getHeight() << endl;
    cout << "Inorder traversal: ";
    binarySearchTree.inorderTraverse(print); 
    cout << endl << endl; 

    cout << "Preorder traversal: ";
    binarySearchTree.preorderTraverse(print); 
    cout << endl << endl;

    cout << "Postorder traversal: ";
    binarySearchTree.postorderTraverse(print);
    cout << endl << endl; 
    fclose(stdout);

    return 0;
}

void print(int& item){
    cout << item << " ";
}