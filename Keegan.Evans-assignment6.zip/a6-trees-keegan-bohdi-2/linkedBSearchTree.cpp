// Keegan Evans & Bohdi Norvell
// CS 302 HW 6 - Trees
// November 24, 2024

template <class ItemType>
LinkedTreeNode<ItemType>* LinkedBSearchTree<ItemType>::placeNode(LinkedTreeNode<ItemType>* subTreePtr, LinkedTreeNode<ItemType>* newNodePtr){
    if(subTreePtr == nullptr)
        return newNodePtr;

    if(newNodePtr->getItem() < subTreePtr->getItem()){
        LinkedTreeNode<ItemType>* temp = placeNode(subTreePtr->getLeftChildPtr(), newNodePtr);
        subTreePtr->setLeftChildPtr(temp);
    }
    else{
        LinkedTreeNode<ItemType>* tempPtr = placeNode(subTreePtr->getRightChildPtr(), newNodePtr);
        subTreePtr->setRightChildPtr(tempPtr);
    }
    return subTreePtr;
}

template <class ItemType>
LinkedTreeNode<ItemType>* LinkedBSearchTree<ItemType>::removeValue(LinkedTreeNode<ItemType>* subTreePtr, const ItemType target, bool& isSuccessful){
    if(subTreePtr == nullptr){
        isSuccessful = false;
        return nullptr;
    }

    if(target < subTreePtr->getItem()){
        LinkedTreeNode<ItemType>* tempPtr = removeValue(subTreePtr->getLeftChildPtr(), target, isSuccessful);
        subTreePtr->setLeftChildPtr(tempPtr);
    }
    else if(target > subTreePtr->getItem()){
        LinkedTreeNode<ItemType>* tempPtr = removeValue(subTreePtr->getRightChildPtr(), target, isSuccessful);
        subTreePtr->setRightChildPtr(tempPtr);
    } 
    else{
        subTreePtr = removeNode(subTreePtr);
        isSuccessful = true;
    }

    return subTreePtr;
}

template <class ItemType>
LinkedTreeNode<ItemType>* LinkedBSearchTree<ItemType>::removeNode(LinkedTreeNode<ItemType>* nodePtr){
    if(nodePtr->getLeftChildPtr() == nullptr && nodePtr->getRightChildPtr() == nullptr){
        delete nodePtr;
        nodePtr = nullptr;
        return nodePtr;
    }

    if(nodePtr->getLeftChildPtr() == nullptr){
        LinkedTreeNode<ItemType>* newPtr = nodePtr->getRightChildPtr();
        delete nodePtr;
        nodePtr = nullptr;
        return newPtr;
    }

    if(nodePtr->getRightChildPtr() == nullptr){
        LinkedTreeNode<ItemType>* newPtr = nodePtr->getLeftChildPtr();
        delete nodePtr;
        nodePtr = nullptr;
        return newPtr;
    }

    
    ItemType newNodeValue;
    nodePtr->setRightChildPtr(removeLeftmostNode(nodePtr->getRightChildPtr(), newNodeValue));
    nodePtr->setItem(newNodeValue);
    return nodePtr;
}

template <class ItemType>
LinkedTreeNode<ItemType>* LinkedBSearchTree<ItemType>::removeLeftmostNode(LinkedTreeNode<ItemType>* nodePtr, ItemType& inorderSuccessor){
    if (nodePtr->getLeftChildPtr() == nullptr){
        inorderSuccessor = nodePtr->getItem();
        return removeNode(nodePtr);
    }

    nodePtr->setLeftChildPtr(removeLeftmostNode(nodePtr->getLeftChildPtr(), inorderSuccessor));
    return nodePtr;
}

template <class ItemType>
LinkedTreeNode<ItemType>* LinkedBSearchTree<ItemType>::findNode(LinkedTreeNode<ItemType>* subTreePtr, const ItemType& target, bool& isSuccessful) const{
    if (subTreePtr == nullptr) {
        isSuccessful = false;
        return nullptr; 
    } 
    else if (subTreePtr->getItem() == target) {
        isSuccessful = true;
        return subTreePtr; 
    } 
    else{
        LinkedTreeNode<ItemType>* leftResult = findNode(subTreePtr->getLeftChildPtr(), target, isSuccessful);
        if (isSuccessful){
            return leftResult;
        } 
        else{
            return findNode(subTreePtr->getRightChildPtr(), target, isSuccessful);
        }
    }
}


template <class ItemType>
void LinkedBSearchTree<ItemType>::preorder(void visit(ItemType&), LinkedTreeNode<ItemType>* treePtr) const{
    if(treePtr != nullptr){
        ItemType item = treePtr->getItem();
        visit(item);

        preorder(visit, treePtr->getLeftChildPtr());
        preorder(visit, treePtr->getRightChildPtr());
    }
}

template <class ItemType>
void LinkedBSearchTree<ItemType>::inorder(void visit(ItemType&), LinkedTreeNode<ItemType>* treePtr) const{
    if(treePtr != nullptr){
        inorder(visit, treePtr->getLeftChildPtr());
        ItemType item = treePtr->getItem();
        visit(item);
        inorder(visit, treePtr->getRightChildPtr());
    }
}

template <class ItemType>
void LinkedBSearchTree<ItemType>::postorder(void visit(ItemType&), LinkedTreeNode<ItemType>* treePtr) const{
    if(treePtr != nullptr){
        postorder(visit, treePtr->getLeftChildPtr());
        postorder(visit, treePtr->getRightChildPtr());
        ItemType item = treePtr->getItem();
        visit(item);
    }
}

template <class ItemType>
LinkedBSearchTree<ItemType>::LinkedBSearchTree() : rootPtr(nullptr) {
}

template <class ItemType>
ItemType LinkedBSearchTree<ItemType>::getRootData() const{
    if(rootPtr == nullptr)
        throw "No data";
    return rootPtr->getItem();
}

template <class ItemType>
void LinkedBSearchTree<ItemType>::preorderTraverse(void visit(ItemType&)) const{
    preorder(visit, rootPtr);
}

template <class ItemType>
void LinkedBSearchTree<ItemType>::inorderTraverse(void visit(ItemType&)) const{
    inorder(visit, rootPtr);
}

template <class ItemType>
void LinkedBSearchTree<ItemType>::postorderTraverse(void visit(ItemType&)) const{
    postorder(visit, rootPtr);
}

template <class ItemType>
LinkedBSearchTree<ItemType>::~LinkedBSearchTree(){
    this->destroyTree(rootPtr);
}

template <class ItemType>
bool LinkedBSearchTree<ItemType>::add(const ItemType& newData){
    LinkedTreeNode<ItemType>* newNodePtr = new LinkedTreeNode<ItemType>(newData);
    rootPtr = placeNode(rootPtr, newNodePtr);
    return true;
}

template <class ItemType>
bool LinkedBSearchTree<ItemType>::remove(const ItemType& data){
    bool successful = false;
    rootPtr = removeValue(rootPtr, data, successful);
    return successful;
}

template <class ItemType>
int LinkedBSearchTree<ItemType>::getHeightHelper(LinkedTreeNode<ItemType>* subTreePtr) const{
    if (subTreePtr == nullptr){
        return 0; 
    }
    else{
        int leftHeight = getHeightHelper(subTreePtr->getLeftChildPtr());
        int rightHeight = getHeightHelper(subTreePtr->getRightChildPtr());

        if (leftHeight > rightHeight) {
            return leftHeight + 1;
        } 
        else{
            return rightHeight + 1;
        }
    }
}

template <class ItemType>
int LinkedBSearchTree<ItemType>::getHeight() const{
    return getHeightHelper(rootPtr);
}

template <class ItemType>
bool LinkedBSearchTree<ItemType>::contains(const ItemType& anEntry) const{
    bool isSuccessful = false;
    findNode(rootPtr, anEntry, isSuccessful);
    return isSuccessful;
}