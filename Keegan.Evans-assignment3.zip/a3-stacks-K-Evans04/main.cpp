//Author: Keegan Evans
//Date: 10/11/2024
//Purpose: HW 3

#include <iostream>
#include <string>
using namespace std;

#include "arrayStack.h"
#include "linkedStack.h"

string infixToPostFix(string);
float expressionToValue(string);
bool isOperator(char);
int hasPrecedence(char);
float calculate(char, float, float);

int main() {
    string expression;
    cout << "Please enter Math Equation: ";
    getline(cin, expression);
    cout << infixToPostFix(expression) << endl;
    expression = infixToPostFix(expression);
    cout << expressionToValue(expression) << endl;

    return 0;
}

string infixToPostFix(string s){
    LinkedStack<char> stack;
    string output;

    for(size_t i = 0; i < s.length(); i++){
        char c = s[i];
        
        if(!isOperator(c) && c != '(' && c !=')' && c != ' '){
            output += c;
        }

        if(c == '('){
            stack.push(c);
        }

        if(c == ')'){
            while(!stack.isEmpty() && stack.peek() != '('){
                output += stack.peek();
                stack.pop();
            }

            if(!stack.isEmpty() && stack.peek() == '('){
                stack.pop();
            }
        }

        if(isOperator(c)){
            while(!stack.isEmpty() && hasPrecedence(stack.peek()) >= hasPrecedence(c)){
                output += stack.peek();
                stack.pop();
            }
            stack.push(c);
        }
    }

    while(!stack.isEmpty()){
        output += stack.peek();
        stack.pop();
    }
    return output;
}

float expressionToValue(string s){
    LinkedStack<float> numStack;
    float num1, num2;

    for(size_t i = 0; i < s.length(); i++){
        char c = s[i];
        if(!isOperator(c) && c != '(' && c !=')' && c != ' '){
            numStack.push(c - '0'); // Stack overflow helped with this line
        }

        if(isOperator(c)){
            num1 = numStack.peek();
            numStack.pop();

            num2 = numStack.peek();
            numStack.pop();
 
            numStack.push(calculate(c, num2, num1));
        }       
    }

    return numStack.peek();
}

bool isOperator(char c){
    return c == '+'|| c == '-'|| c == '*'|| c == '/';
}

int hasPrecedence(char operation){
    if(operation == '+' || operation == '-')
        return 1;
    
    if(operation == '*' || operation == '/')
        return 2;
    
    return 0;
}

float calculate(char c, float f1, float f2){
    switch (c) {
        case '+':
            return f1 + f2;
        case '-':
            return f1 - f2;
        case '*':
            return f1 * f2;
        case '/':
            if(f2 != 0)
                return f1 / f2;
            
            throw "Denominator is 0";
        
        default:
            throw "is not an operator";
    }
}