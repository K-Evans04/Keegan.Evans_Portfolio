#include "linkedStack.h"

template<class ItemType>
LinkedStack<ItemType>::LinkedStack(){
    top = nullptr;
}

template<class ItemType>
bool LinkedStack<ItemType>::isEmpty() const{
    return top == nullptr;
}

template<class ItemType>
bool LinkedStack<ItemType>::push(const ItemType& newEntry){
    Node<ItemType>* node = new Node<ItemType>;
    
    node->setItem(newEntry);
    node->setNext(top);
    top = node;

    return true;
}

template<class ItemType>
bool LinkedStack<ItemType>::pop(){
    bool canPop = !isEmpty();

    if(canPop){
        Node<ItemType>* oldNode = top;
        top = top->getNext();
        delete oldNode;
    }

    return canPop;
}

template<class ItemType>
ItemType LinkedStack<ItemType>::peek() const{
    bool canPeek = !isEmpty();

    if(canPeek){
        return top->getItem();
    }

    throw "empty stack";
}

template<class ItemType>
LinkedStack<ItemType>::~LinkedStack(){
    while(!isEmpty()){
        Node<ItemType>* nodeToDelete = top;
        top = top->getNext();
        delete nodeToDelete;
    }
}