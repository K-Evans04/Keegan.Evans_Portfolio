#define DNE -100

template<class LabelType>
Graph<LabelType>::Graph() : numVertices(0) {}

template<class LabelType>
int Graph<LabelType>::findIndex(LabelType v) const {
    int i = 0;

    for(typename list<LabelType>::const_iterator it = vertices.begin(); it != vertices.end(); it++){ // I used stack overflow to learn how to iterate through a list
        if(*it == v){
            return i;
        }

        i++;
    }
    return DNE;
}

template<class LabelType>
int Graph<LabelType>::getNumVertices() const {
    return numVertices;
}

template<class LabelType>
int Graph<LabelType>::getNumEdges() const {
    return edges.size();
}

template<class LabelType>
bool Graph<LabelType>::add(LabelType start, LabelType end, int edgeWeight){
    Edge newEdge(start, end, edgeWeight);
    
    if(findIndex(start) == DNE){
        vertices.push_back(start);
        numVertices++;
    }
    if(findIndex(end) == DNE){
        vertices.push_back(end);
        numVertices++;
    }


    edges.push_back(newEdge);
    return true;
}

template<class LabelType>
bool Graph<LabelType>::remove(LabelType start, LabelType end) {
    for(typename list<Edge>::iterator it = edges.begin(); it != edges.end(); it++){
        if(it->getStart() == start && it->getEnd() == end){
            edges.erase(it);
            return true;
        }
    }
    return false;
}

template<class LabelType>
int Graph<LabelType>::getEdgeWeight(LabelType start, LabelType end) const{
    for(list<Edge>::const_iterator it = edges.begin(); it != edges.end(); it++){
        if(it->getStart() == start && it->getEnd() == end){
            return it->getWeight();
        }
    }
    return DNE;
}

template<class LabelType>
void Graph<LabelType>::depthFirstTraversal(LabelType start, void visit(LabelType&)){
    stack<LabelType> stack;
    list<LabelType> visited;

    stack.push(start);
    while(!stack.empty()){
        bool beenVisited = false;
        LabelType current = stack.top();
        stack.pop();

        
        for(typename list<LabelType>::iterator it = visited.begin(); it != visited.end(); it++){
            if(*it == current){
                beenVisited = true;
                break;
            }
        }

        if(!beenVisited){
            visit(current);
            visited.push_back(current);

            for(typename list<Edge>::iterator it = edges.begin(); it != edges.end(); it++){
                if(it->getStart() == current){
                    bool end = false;
                    for(typename list<LabelType>::iterator v = visited.begin(); v != visited.end(); v++){
                        if(*v == it->getEnd()){
                            end = true;
                            break;
                        }
                    }
                
                if(!end) stack.push(it->getEnd());

                }
            }
        }
    }
}

template<class LabelType>
void Graph<LabelType>::breadthFirstTraversal(LabelType start, void visit(LabelType&)){
    queue<LabelType> queue;
    list<LabelType> visited;

    queue.push(start);

    while(!queue.empty()){
        bool beenVisited = false;
        LabelType current = queue.front();
        queue.pop();

        for(typename list<LabelType>::iterator it = visited.begin(); it != visited.end(); it++){
            if(current == *it){
                beenVisited = true;
                break;
            }
        }

        if(!beenVisited){
            visit(current);
            visited.push_back(current);

            for(typename list<Edge>::iterator it = edges.begin(); it != edges.end(); it++){
                if(it->getStart() == current){
                    bool endVisited = false;
                    for(typename list<LabelType>::iterator vit = visited.begin(); vit != visited.end(); vit++){
                        if(it->getEnd() == *vit){
                            endVisited = true;
                            break;
                        }
                    }
                    
                    if(!endVisited) queue.push(it->getEnd());
                    
                }
            }
        }
    }
}