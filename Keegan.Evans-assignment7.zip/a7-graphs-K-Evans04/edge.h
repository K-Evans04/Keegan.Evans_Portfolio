#ifndef EDGE_H
#define EDGE_H

#include <string>
using namespace std;

class Edge{
    string start, end;
    int weight;

public:
    Edge() : start(""), end(""), weight(0){}
    Edge(string s, string e, int w) : start(s), end(e), weight(w){}
    Edge(const Edge& rhs) : start(rhs.start), end(rhs.end), weight(rhs.weight){}

    void setStart(string s){start = s;}
    string getStart() const {return start;}

    void setEnd(string s){end = s;}
    string getEnd() const {return end;}

    void setWeight(int w){weight = w;}
    int getWeight() const {return weight;}
};

#endif 