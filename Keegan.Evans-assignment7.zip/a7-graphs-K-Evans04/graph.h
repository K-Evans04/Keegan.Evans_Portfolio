#ifndef GRAPH_H
#define GRAPH_H

#include "graphInterface.h"
#include "edge.h"
#include <list>
#include <stack>
#include <queue>
#include <vector>
#include <iostream>

using namespace std;

template<class LabelType>
class Graph : public GraphInterface<LabelType>{ 
    list<Edge> edges;
    list<LabelType> vertices;
    int numVertices;
    int findIndex(LabelType) const;

public:
    Graph();
    int getNumVertices() const;
    int getNumEdges() const;
    bool add(LabelType start, LabelType end, int edgeWeight);
    bool remove(LabelType start, LabelType end);
    int getEdgeWeight(LabelType start, LabelType end) const;
    void depthFirstTraversal(LabelType start, void visit(LabelType&));
    void breadthFirstTraversal(LabelType start, void visit(LabelType&));
};

#include "graph.cpp"
#endif