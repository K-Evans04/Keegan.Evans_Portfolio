//Author: Keegan Evans
//Date: 12/8/2024
//Purpose: CS302 HW7

#include "graph.h"
#include <fstream>
#include <list>
#include <string>
#include <vector>
#include <iostream>

using namespace std;

void findPaths(list<int> &cityIndex, int first, list<list<int>> &paths);
double calculateGas(Graph<string>& graph, const list<int>& path, const list<string>& cities);

int main(){
    int distance;
    double minGas = 1000000.0;
    string city1, city2, s_distance;
    Graph<string> graph;
    list<int> bestPath, cityIndex = {0, 1, 2, 3, 4};
    list<list<int>> paths;
    list<string> cities = {"Reno", "San Francisco", "Salt Lake City", "Seattle", "Las Vegas"};

    ifstream in("cities.txt");
    while(in.good()){
        getline(in, city1, ',');
        getline(in, city2, ',');
        getline(in, s_distance);
        distance = stoi(s_distance);

        graph.add(city1, city2, distance);
        graph.add(city2, city1, distance);
    }
    
    in.close();

    findPaths(cityIndex, 1, paths);

    for(list<list<int>>::const_iterator pathI = paths.begin(); pathI != paths.end(); pathI++){ 
        int gas = calculateGas(graph, *pathI, cities);
        if(gas < minGas){
            minGas = gas;
            bestPath = *pathI;
        }
    }

    ofstream out("paths.txt");

    for(list<list<int>>::const_iterator pathI = paths.begin(); pathI != paths.end(); pathI++){ //learned .begin and front from geeks for geeks
        for(list<int>::const_iterator cityIndex = pathI->begin(); cityIndex != pathI->end(); cityIndex++){
            list<string>::const_iterator cityI = cities.begin();
            for(int i = 0; i < *cityIndex; i++){
                cityI++;
            }
            out << *cityI << " ";
        }
        
        list<string>::const_iterator cityI = cities.begin();
        for(int i = 0; i < pathI->front(); i++){
            cityI++;
        }

        out << *cityI << " ";
        out << "/ Gallons of Gas : " << calculateGas(graph, *pathI, cities) << endl;
    }

    out << endl << "Best Path: ";
    
    for(list<int>::const_iterator cityIndex = bestPath.begin(); cityIndex != bestPath.end(); cityIndex++){
        list<string>::const_iterator cityI = cities.begin();
        for(int i = 0; i < *cityIndex; i++){
            cityI++;
        }
        out << *cityI << " ";
    }
    
    list<string>::const_iterator cityI = cities.begin();
    
    for(int i = 0; i < bestPath.front(); i++){
        cityI++;
    }

    out << *cityI << " ";
    out << "/ Gallons of Gas: " << minGas << endl;

    out.close();

    return 0;
}

void findPaths(list<int> &cityIndex, int first, list<list<int>> &paths){
    list<int>::iterator it = cityIndex.begin();
    
    if(first == static_cast<int>(cityIndex.size()) - 1){
        paths.push_back(cityIndex);
    }

    for(int i = 0; i < first; i++){
        it++;
    }

    for(list<int>::iterator i = it; i != cityIndex.end(); i++){
        int temp = *it;
        *it = *i;
        *i = temp;

        findPaths(cityIndex, first + 1, paths);
        
        temp = *it;
        *it = *i;
        *i = temp;
    }
}

double calculateGas(Graph<string>& graph, const list<int>& path, const list<string>& cities) {
    int fuelEfficiency = 40;
    int totalDistance = 0;
    string startCity, endCity;
    list<int>::const_iterator pathI = path.begin();
    list<string>::const_iterator cityI = cities.begin();

    for(int i = 0; i < *pathI; i++){
        cityI++;
    }
    
    startCity = *cityI;
    
    while(pathI != path.end()){
        cityI = cities.begin();
        
        for(int i = 0; i < *pathI; i++){
            cityI++;
        }
        
        endCity = *cityI;
        int distance = graph.getEdgeWeight(startCity, endCity);
        
        if(distance == DNE){
            return 1000000;   
        }
        
        totalDistance += distance;
        startCity = endCity;
        pathI++;
    }

    cityI = cities.begin();
    for(int i = 0; i < path.front(); i++){
        cityI++;
    }

    int returnDistance = graph.getEdgeWeight(startCity, *cityI);
    
    if(returnDistance == DNE){
        return 1000000;
    }
    
    totalDistance += returnDistance;
    double totalGallonsOfGas = (totalDistance / fuelEfficiency);

    return totalGallonsOfGas;
}