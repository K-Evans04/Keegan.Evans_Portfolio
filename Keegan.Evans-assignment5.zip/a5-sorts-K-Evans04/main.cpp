#include "sorting.h"
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <chrono>

using namespace std::chrono;

void Bubble(int[], int, long long int &, long long int &, ofstream &);
void Insertion(int[], int, long long int &, long long int &, ofstream&);
void Quick(int[], int, long long int &, long long int &, ofstream&);

int main(){
    srand(time(0));
    
    long long int swaps = 0, comparisons = 0;

    int arr1[1000];
    int arr2[10000];
    int arr3[100000];
    
    ofstream write1("Bubble1000.csv");
    Bubble(arr1, 1000, swaps, comparisons, write1);
    ofstream write2("Bubble10000.csv");
    Bubble(arr2, 10000, swaps, comparisons, write2);
    ofstream write3("Bubble100000.csv");
    Bubble(arr3, 100000, swaps, comparisons, write3);      

    ofstream write4("Insertion1000.csv");
    Insertion(arr1, 1000, swaps, comparisons, write4);
    ofstream write5("Insertion10000.csv");
    Insertion(arr2, 10000, swaps, comparisons, write5);
    ofstream write6("Insertion100000.csv");
    Insertion(arr3, 100000, swaps, comparisons, write6);
    
    ofstream write7("Quick1000.csv");
    Quick(arr1, 1000, swaps, comparisons, write7);
    ofstream write8("Quick10000.csv");
    Quick(arr2, 10000, swaps, comparisons, write8);
    ofstream write9("Quick100000.csv");
    Quick(arr3, 100000, swaps, comparisons, write9);
    
    return 0;
}

void Bubble(int arr[], int n, long long int &swaps, long long int &comparisons, ofstream &write){
    for(int i = 0; i < 10; i++){
        for (int i = 0; i < n; i++) {
            arr[i] = rand() % 1000000 + 1;
        }
        swaps = comparisons = 0;
        auto start = high_resolution_clock::now();
        bubbleSort(arr, n, swaps, comparisons);
        auto stop = high_resolution_clock::now();
        auto duration = duration_cast<microseconds>(stop - start);
        
        if(write.is_open()){
            write << duration.count() << ","
                  << comparisons << ","
                  << swaps << endl;
        }
    }
    
    write << endl;

    for(int i = 0; i < 10; i++){
        swaps = comparisons = 0;
        auto start = high_resolution_clock::now();
        bubbleSort(arr, n, swaps, comparisons);
        auto stop = high_resolution_clock::now();
        auto duration = duration_cast<microseconds>(stop - start);
        
        if(write.is_open()){
            write << duration.count() << ","
                  << comparisons << ","
                  << swaps << endl;
        }
    }
    
    write.close();
}

void Insertion(int arr[], int n, long long int &swaps, long long int &comparisons, ofstream &write){

    for(int i = 0; i < 10; i++){
        for (int i = 0; i < n; i++) {
            arr[i] = rand() % 1000000 + 1;
        }
        swaps = comparisons = 0;
        auto start = high_resolution_clock::now();
        insertionSort(arr, n, swaps, comparisons);
        auto stop = high_resolution_clock::now();
        auto duration = duration_cast<microseconds>(stop - start);
        
        if(write.is_open()){
            write << duration.count() << ","
                  << comparisons << ","
                  << swaps << endl;
        }
    }
    
    write << endl;

    for(int i = 0; i < 10; i++){
        swaps = comparisons = 0;
        auto start = high_resolution_clock::now();
        insertionSort(arr, n, swaps, comparisons);
        auto stop = high_resolution_clock::now();
        auto duration = duration_cast<microseconds>(stop - start);
        
        if(write.is_open()){
            write << duration.count() << ","
                  << comparisons << ","
                  << swaps << endl;
        }
    }
    
    write.close();
}

void Quick(int arr[], int n, long long int &swaps, long long int &comparisons, ofstream &write){
    for(int i = 0; i < 10; i++){
        for (int i = 0; i < n; i++) {
            arr[i] = rand() % 1000000 + 1;
        }
        swaps = comparisons = 0;
        auto start = high_resolution_clock::now();
        quickSort(arr, 0, n - 1, swaps, comparisons);
        auto stop = high_resolution_clock::now();
        auto duration = duration_cast<microseconds>(stop - start);
        
        if(write.is_open()){
            write << duration.count() << ","
                  << comparisons << ","
                  << swaps << endl;
        }
    }
    
    write << endl;
    
    for(int i = 0; i < 10; i++){
        swaps = comparisons = 0;
        auto start = high_resolution_clock::now();
        quickSort(arr, 0, n - 1, swaps, comparisons);
        auto stop = high_resolution_clock::now();
        auto duration = duration_cast<microseconds>(stop - start);
        
        if(write.is_open()){
            write << duration.count() << ","
                  << comparisons << ","
                  << swaps << endl;
        }
    }
    
    write.close();
}