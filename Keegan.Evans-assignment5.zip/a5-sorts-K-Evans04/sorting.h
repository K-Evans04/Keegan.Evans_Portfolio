#ifndef SORTING_H
#define SORTING_H

#include <iostream>
using namespace std;


void bubbleSort(int array[], int n, long long int &swaps, long long int &comparisons) {
    swaps = comparisons = 0;

    for(int i = 0; i < n - 1; i++){
        for(int j = 0; j < n - i - 1; j++){
            comparisons++;
            if(array[j] > array[j + 1]){
                int temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;
                swaps++;
            }
        }
    }
}

void insertionSort(int array[], int n, long long int &swaps, long long int &comparisons){
    swaps = comparisons = 0;

    for(int i = 1; i < n - 1; i++){
        int num = array[i];
        int j = i - 1;
        while(j >= 0 && array[j] > num){
            comparisons++;
            array[j + 1] = array[j];
            j--;
            swaps++;
        }
        array[j + 1] = num;
        comparisons++;
    }
}

int partition(int array[], int low, int high, long long int &swaps, long long int &comparisons){
    int pivotValue = array[high];
    int i = low - 1;
    
    for(int j = low; j < high; j++){
        comparisons++;
        if(array[j] <= pivotValue){
            i++;
            int temp = array[i];
            array[i] = array[j];
            array[j] = temp;
            
            swaps++;
        } 
    }
    int temp = array[i + 1];
    array[i + 1] = array[high];
    array[high] = temp;
    swaps++;

    return i + 1;
}

void quickSort(int array[], int low, int high, long long int &swaps, long long int &comparisons){
    if(low < high){
        int pivot = partition(array, low, high, swaps, comparisons);
        
        quickSort(array, low, pivot - 1, swaps, comparisons);
        quickSort(array, pivot + 1, high, swaps, comparisons);
    }
};

#endif