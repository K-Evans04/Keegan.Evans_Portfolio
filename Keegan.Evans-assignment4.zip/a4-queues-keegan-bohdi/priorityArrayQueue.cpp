#include "priorityArrayQueue.h"

template<typename T>
priorityArrayQueue<T>::priorityArrayQueue(){
   front = 0;
   rear = -1;
   numItems = 0;
}

template<typename T>
bool priorityArrayQueue<T>::isEmpty() const{
   return numItems == 0;
}

template<typename T>
bool priorityArrayQueue<T>::enqueue(const T& newEntry){
   if(isEmpty()){
      getQueue()[front] = newEntry;
      numItems++;
      rear = (rear+1) % DEFAULT_CAPACITY_P;
      return true;
   }
   else{
      rear = (rear+1) % DEFAULT_CAPACITY_P;
      priorityQueue[rear] = newEntry;
      numItems++;
      reorder();
      return true;
   }
   return false;
}

template<typename T>
bool priorityArrayQueue<T>::dequeue(){
   if(!isEmpty()){
      if(front == rear){
         front = rear = -1;
         numItems--;
         return true;
      }
      front = (front + 1) % numItems;
      numItems--;
      return true;
   }

   return false;
}

template<typename T>
T priorityArrayQueue<T>::peekFront() const{
   if(!isEmpty()){
      return priorityQueue[front];
   }
   throw "Queue is empty";
}

template<typename T>
void priorityArrayQueue<T>::reorder(){

   int n = numItems;
   int i = rear;
   while (n > 1) {
      int prevIndex = (i - 1 + DEFAULT_CAPACITY_P) % DEFAULT_CAPACITY_P;
      if (priorityQueue[prevIndex].getTime() <= priorityQueue[i].getTime()) {
         break;
      }
      T temp = priorityQueue[i];
      priorityQueue[i] = priorityQueue[prevIndex];
      priorityQueue[prevIndex] = temp;
      i = prevIndex;
      n--;
   }
}

template<typename T>
int priorityArrayQueue<T>::getFront(){
   return front;
}
template<typename T>
int priorityArrayQueue<T>::getRear(){
   return rear;
}
template<typename T>
int priorityArrayQueue<T>::getNumItems(){
   return numItems;
}
template<typename T>
T* priorityArrayQueue<T>::getQueue(){
   return priorityQueue;
}
template<typename T>
void priorityArrayQueue<T>::setFront(int f){
   front = f;
}
template<typename T>
void priorityArrayQueue<T>::setRear(int r){
   rear = r;
}
template<typename T>
void priorityArrayQueue<T>::setNumItems(int n){
   numItems = n;
}
template<typename T>
void priorityArrayQueue<T>::setQueue(T* q){
   int itemNum = q.getNumItems();
   for(int i =0; i < itemNum; i++){
      getQueue()[i]=q.getQueue()[i];
   }
}