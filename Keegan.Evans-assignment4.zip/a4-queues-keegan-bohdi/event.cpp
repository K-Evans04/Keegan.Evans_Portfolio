#include "event.h"

Event::Event(){
    time = 0;
    transactionTime = 0;
    eventType = "";
}

Event::Event(int t, int tTime, string type){
    time = t;
    transactionTime = tTime;
    eventType = type;
}

Event::Event(const Event& rhs){
    time = rhs.time;
    transactionTime = rhs.transactionTime;
    eventType = rhs.eventType;
}

int Event::getTime(){
    return time;
}

int Event::getTransactionTime(){
    return transactionTime;
}

string Event::getEventType(){
    return eventType;
}

void Event::setTime(int t){
    time = t;
}

void Event::setTransactionTime(int t){
    transactionTime = t;
}

void Event::setEventType(string type){
    eventType = type;
}

bool Event::operator<(const Event& rhs){
    return time < rhs.time;
}