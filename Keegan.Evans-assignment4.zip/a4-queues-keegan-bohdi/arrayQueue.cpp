#include "arrayQueue.h"

template<typename T>
ArrayQueue<T>::ArrayQueue(){
   front = -1;
   rear = -1;
   numItems = 0;
}

template<typename T>
bool ArrayQueue<T>::isEmpty() const{
   return numItems == 0;
}

template<typename T>
bool ArrayQueue<T>::enqueue(const T& newEntry){
   if(isEmpty()){
      front++;
      queueArray[front] = newEntry;
      numItems++;
      rear = (rear+1) % DEFAULT_CAPACITY;
      return true;
   }
   else{
       rear = (rear+1) % DEFAULT_CAPACITY;
       queueArray[rear] = newEntry;
       numItems++;
       return true;
   }
   return false;
}

template<typename T>
bool ArrayQueue<T>::dequeue(){
   if(!isEmpty()){
      if(front == rear){
         front = rear = -1;
         numItems--;
         return true;
      }
      front = (front + 1) % numItems;
      numItems--;
      return true;
   }

   return false;
}

template<typename T>
T ArrayQueue<T>::peekFront() const{
   if(!isEmpty()){
      return queueArray[front];
   }
   throw "Queue is empty";
}
template<typename T>
int ArrayQueue<T>::getFront(){
   return front;
}
template<typename T>
int ArrayQueue<T>::getRear(){
   return rear;
}
template<typename T>
int ArrayQueue<T>::getNumItems(){
   return numItems;
}
template<typename T>
T* ArrayQueue<T>::getQueue(){
   return queueArray;
}
template<typename T>
void ArrayQueue<T>::setFront(int f){
   front = f;
}
template<typename T>
void ArrayQueue<T>::setRear(int r){
   rear = r;
}
template<typename T>
void ArrayQueue<T>::setNumItems(int n){
   numItems = n;
}
template<typename T>
void ArrayQueue<T>::setQueue(T* q){
   int itemNum = q.getNumItems();
   for(int i =0; i < itemNum; i++){
      queueArray[i]=q.getQueue()[i];
   }
}