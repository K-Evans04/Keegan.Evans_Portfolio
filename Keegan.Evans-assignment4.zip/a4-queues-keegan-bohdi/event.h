#ifndef EVENT_H
#define EVENT_H

#include <iostream>
#include <string>
using namespace std;

class Event{
    int time, transactionTime;
    string eventType;

    public:
        Event();
        Event(int, int, string);
        Event(const Event&);

        int getTime();
        int getTransactionTime();
        string getEventType();

        void setTime(int);
        void setTransactionTime(int);
        void setEventType(string);

        bool operator<(const Event&);
};
#endif