#ifndef PRIORITY_ARRAY_QUEUE
#define PRIORITY_ARRAY_QUEUE

#include "queue.h"
#include <iostream>

#define DEFAULT_CAPACITY_P 20

template<typename T>
class priorityArrayQueue: public QueueInterface<T> {
    T priorityQueue[DEFAULT_CAPACITY_P];
    int front, rear, numItems;

public:
    priorityArrayQueue();

    bool isEmpty() const; 
    bool enqueue(const T& newEntry); 
    bool dequeue(); 
    T peekFront() const;     
    ~priorityArrayQueue() {}    

    int getFront();
    int getRear();
    int getNumItems();
    T* getQueue();

    void setFront(int);
    void setRear(int);
    void setNumItems(int);
    void setQueue(T*); 

    void reorder();
};

#include "priorityArrayQueue.cpp"
#endif