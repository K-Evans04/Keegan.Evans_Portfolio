#ifndef ARRAY_QUEUE
#define ARRAY_QUEUE

#include "queue.h"
#include <iostream>

#define DEFAULT_CAPACITY 10

template<typename T>
class ArrayQueue: public QueueInterface<T> {
    T queueArray[DEFAULT_CAPACITY];
    int front, rear, numItems;

public:
    ArrayQueue();

    bool isEmpty() const; 
    bool enqueue(const T& newEntry); 
    bool dequeue(); 
    T peekFront() const;     
    ~ArrayQueue() {}

    int getFront();
    int getRear();
    int getNumItems();
    T* getQueue();

    void setFront(int);
    void setRear(int);
    void setNumItems(int);
    void setQueue(T*);     
};

#include "arrayQueue.cpp"
#endif