// Author: Keegan Evans
// Date: 10/20/2024
// Purpose: Homework 5

#include "priorityArrayQueue.h"
#include "arrayQueue.h"
#include "event.h"
#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;

ArrayQueue<Event> loadInputFile(string);
void displaySimulation(priorityArrayQueue<Event>, float);
ArrayQueue<Event> calculateDepartureEvent(ArrayQueue<Event>);
float calculateWaitAverage(ArrayQueue<Event>);

int main(){
    ArrayQueue<Event> arrivalQ = loadInputFile("input.txt");
    ArrayQueue<Event> departureQ = calculateDepartureEvent(arrivalQ);
    float avgWaitTime = calculateWaitAverage(departureQ);
    priorityArrayQueue<Event> allEventQ;
    for(int i = 0; i<arrivalQ.getNumItems(); i++){
       allEventQ.enqueue(arrivalQ.getQueue()[i]);
       allEventQ.enqueue(departureQ.getQueue()[i]);
    }
    displaySimulation(allEventQ, avgWaitTime);
    return 0;
}

ArrayQueue<Event> loadInputFile(string fileName){
    ArrayQueue<Event> aQueue;
    int arrival, transaction;
    string fileLine;
    ifstream inputFile(fileName);
    if(!inputFile.is_open()){
        throw "CAN NOT OPEN INPUT FILE";
    }
    while(!inputFile.eof()){
        getline(inputFile, fileLine);
        istringstream iss(fileLine);
        iss >> arrival >> transaction;
        Event anArrival(arrival, transaction, "ARRIVAL");
        aQueue.enqueue(anArrival);
    }
    inputFile.close();
    return aQueue;
}
void displaySimulation(priorityArrayQueue<Event> queueAD, float avgTime){
    int peopleProcessed = 0;
    cout << "Simulation Begins" << endl;
    for(int i = 0; i < queueAD.getNumItems(); i ++){
        if(queueAD.getQueue()[i].getEventType() == "ARRIVAL"){
            cout << "Processing an arrival event at time: " << queueAD.getQueue()[i].getTime() << endl;
            peopleProcessed++;
        }
        if(queueAD.getQueue()[i].getEventType() == "DEPARTURE"){
            cout << "Processing a departure event at time: " << queueAD.getQueue()[i].getTime() << endl;
        }
    }
    cout << "Simulation Ends" << endl << endl;
    cout << "Total number of people processed: " << peopleProcessed << endl;
    cout << "Average amount of time spent waiting: " << avgTime << endl;
}

ArrayQueue<Event> calculateDepartureEvent(ArrayQueue<Event> arrivals){
    int waitTime, departureTime, prevTime, count = 0;
    ArrayQueue<Event> departureQ;

    while(!arrivals.isEmpty()){
        Event arrival = arrivals.getQueue()[count];
        if(count == 0){
            waitTime = 0;
            departureTime = arrival.getTime() + arrival.getTransactionTime() + waitTime;
        }else{
            prevTime = departureQ.getQueue()[count-1].getTime();
            if(prevTime <= arrival.getTime()){
                waitTime = 0;
            }
            else{
                waitTime = prevTime - arrival.getTime();
            }
            
            departureTime = arrival.getTime() + waitTime + arrival.getTransactionTime();
        }
        Event departure(departureTime, waitTime, "DEPARTURE");
        departureQ.enqueue(departure);
        arrivals.dequeue();
        count++;
    }

    return departureQ;
}

float calculateWaitAverage(ArrayQueue<Event> departures){
    float total = 0;
    for(int i = 0; i < departures.getNumItems(); i++){
        total += departures.getQueue()[i].getTransactionTime();
    }
    float avg = total/departures.getNumItems();
    return avg;
}