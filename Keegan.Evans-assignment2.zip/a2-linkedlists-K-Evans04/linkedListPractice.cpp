#include "linkedlist.h"

template<class ItemType>
Node<ItemType>* LinkedList<ItemType>::getNodeAt(int position) const {
    bool ableToGet == (itemCount >= 1) && (position <= itemCount);
    
    if(ableToGet){
        Node<ItemType>* curPtr = headPtr;
        for(int i = 0; i < itemCount; i++){
            curPtr = curPtr->getNext()
        }
        return curPtr;
    }
    return nullptr;
}

template<class ItemType>
LinkedList<ItemType>::LinkedList() : headPtr(nullptr), itemCount(0){}

template<class ItemType>
LinkedList<ItemType>::LinkedList(const LinkedList<ItemType>& aList){
    itemCount = aList.itemCount;

    if(itemCount > 1){
       headPtr = new Node<ItemType>;
       headPtr->setItem(aList.headPtr->getNext());

       Node<ItemType>* curPtr = headPtr;
       Node<ItemType>* nxtPtr = aList.headPtr->getNext();

       while(nxtPtr){
            Node<ItemType>* newPtr = new Node<ItemType>(curPtr->getItem());
            nxtPtr->setNext(newPtr);
            nxtPtr = nxtPtr->getNext();
            curPtr = curPtr->getNext();
       }
       nxtPtr->setNext(nullptr);
    }
    else headPtr nullptr;
}

template<class ItemType>
bool LinkedList<ItemType>::isEmpty() const{
    return itemCount == 0;
}

template<class ItemType>
int LinkedList<ItemType>::getLength() const{
    return itemCount;
}

template<class ItemType>
bool LinkedList<ItemType>::insert(int newPosition, const ItemType& newEntry){
    bool ableToInsert = (newPosition >= 1) && (newPosition <= itemCount);
    if(ableToInsert){
        Node<ItemType>* newPtr = new Node<ItemType>(newEntry);

        if(newPosition == 1){
            newPtr->setNext(headPtr);
                headPtr = newPtr;
        }
        else{
            Node<ItemType>* prevPtr = getNodeAt(newPosition - 1);
            newPtr->setNext(prevPtr->getNext);
            prevPtr->setNext(newPtr);
        }
        itemCount++;
    }
    return ableToInsert;
}

template<class ItemType>
bool LinkedList<ItemType>::remove(int position){
    bool ableToRemove = (position >= 1) && (position <= itemCount);
    if(ableToRemove){
        Node<ItemType>* ptrToDelete = nullptr;
        if(position == 1){
            ptrToDelete = headPtr;
            headPtr = headPtr->getNext();
        }
        else{
            Node<ItemType>* prevPtr = getNodeAt(position - 1);
            ptrToDelete = prevPtr->getNext();
            prevPtr->setNext(ptrToDelete->getNext());
        }
        ptrToDelete->setNext(nullptr);
        delete ptrToDelete;
        ptrToDelete = nullptr;
        itemCount--;
    }
    return ableToRemove;
}

template<class ItemType>
void LinkedList<ItemType>::clear(){
    Node<ItemType>* curPtr = headPtr;
    while(curPtr){
        Node<ItemType>* temp = curPtr;
        curPtr = curPtr->getNext();
        delete temp;
    }
}

template <class ItemType>
ItemType LinkedList<ItemType>::getEntry(int position) const {
    bool ableToGet = (position >= 1) && (position <= itemCount);
    
    if(ableToGet){
        Node<ItemType>* entry = getNodeAt(position);
        return entry->getItem();
    }
}

template <class ItemType>
ItemType LinkedList<ItemType>::replace(int position, const ItemType& newEntry){
    bool ableToReplace = (position >= 1) && (position <= itemCount);

    if(ableToReplace){
        Node<ItemType>* nodePtr = getNodeAt(position);
        ItemType oldEntry = nodePtr->getItem;
        nodePtr->setItem(newEntry);
        retrun oldEntry;      
    }    
}

template <class ItemType>
LinkedList<ItemType>::~LinkedList(){
    clear();
}